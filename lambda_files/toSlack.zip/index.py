from slacker import Slacker

token = 'xoxb-3991850237587-3994481885252-OMVQU6Lrn6KRG7JC5SGezxto'
slack = Slacker(token)

#def handler(event, context):
#    ch = event["channel"]
#    message = event["message"]

#    slack.chat.post_message(ch, msg)

#if __name__ == '__main__':
#    event= {}
#    event["channel"] = "#general"
#    event["message"] = "메인 테스트"
    
#    handler(event, None)